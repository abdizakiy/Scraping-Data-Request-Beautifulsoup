import requests
from bs4 import BeautifulSoup
# import csv
import pandas as pd
from fake_useragent import UserAgent
import random
import time

list_price     = []
list_address   = []
list_idplace   = []
list_state     = []
list_bed       = []
list_parking   = []
list_bath      = []
list_type      = []


headers = {
    'authority': 'www.realestate.com.au',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'en-US,en;q=0.9',
    'cache-control': 'max-age=0',
    # 'cookie': cookie,
    'referer': 'https://www.realestate.com.au/rent/in-qld/list-1',
    'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"macOS"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
}
params = {
    'activeSort': 'list-date',
}
            

states = ["qld", "nsw", "vic", "sa", "wa", "act", "nt", "tas"]
idx = 1

for state in states:
    page = 1
    time.sleep(10)

    # IF YOU WANT TO GET ALL PAGE USE WHILE TRUE
    # while True:

    # IF YOU WANT TO GET FEW PAGES USE FOR, 
    # CHANGE THE RANGE WITH THE NUMBER OF PAGES YOU WANT
    for _ in range(10):
        link = "https://www.realestate.com.au/rent/in-" + state + "/list-" + str(page)
        print("scanning page " + str(page) + " state " + state)
        for _ in range(10):
            cookie_list = [
                {
                    'reauid': '15b411609fc9210099819565eb010000e3360200',
                    'Country': 'ID',
                    '_ga_F962Q8PWJ0': 'GS1.1.1704296396.2.1.1704296857.0.0.0',
                    'KP_UIDz-ssn': '010kKHemSp9fXoKbjsnljVprfbMacv0QaxUjrf7vEs9hguj1w2Aqm3Aw9UCxRdFE0eM82CwXuLPjczsKE9pnW7AaqLvWN2pNxXJ7fnTMde6HZYuMhBnkDAQNCEjeQjfHOqrDA1xMxdxvuMOQXxuaToF0yJiVDYs64UzaNg4i56Rnhm3yu',
                    'KP_UIDz': '010kKHemSp9fXoKbjsnljVprfbMacv0QaxUjrf7vEs9hguj1w2Aqm3Aw9UCxRdFE0eM82CwXuLPjczsKE9pnW7AaqLvWN2pNxXJ7fnTMde6HZYuMhBnkDAQNCEjeQjfHOqrDA1xMxdxvuMOQXxuaToF0yJiVDYs64UzaNg4i56Rnhm3yu',
                    'split_audience': 'e',
                    'fullstory_audience_split': 'B',
                    'pageview_counter.srs': '1',
                    '_sp_ses.2fe7': '*',
                    'topid': 'REAUID:15B411609FC9210099819565EB010000E3360200',
                    'VT_LANG': 'language%3Den-US',
                    '_gcl_au': '1.1.1943344804.1704297874',
                    'mid': '5582897326969336',
                    '_fbp': 'fb.2.1704297873716.496870772',
                    'AMCVS_341225BE55BBF7E17F000101%40AdobeOrg': '1',
                    's_nr30': '1704297873919-New',
                    '_gid': 'GA1.3.386137534.1704297874',
                    '_gat_gtag_UA_143679184_2': '1',
                    'DM_SitId1464': '1',
                    'DM_SitId1464SecId12708': '1',
                    'nol_fpid': 'huf5xfahkb2hbjc6oqconyfdzmtb31704297874|1704297874217|1704297874217|1704297874217',
                    '_ga_3J0XCBB972': 'GS1.1.1704296396.2.1.1704297874.0.0.0',
                    '_ga': 'GA1.1.123637697.1704297874',
                    '_lr_geo_location_state': 'JI',
                    '_lr_geo_location': 'ID',
                    's_ecid': 'MCMID%7C38166663233962946580741138631908829025',
                    'AMCV_341225BE55BBF7E17F000101%40AdobeOrg': '-330454231%7CMCIDTS%7C19726%7CMCMID%7C38166663233962946580741138631908829025%7CMCAAMLH-1704902673%7C3%7CMCAAMB-1704902673%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1704305073s%7CNONE%7CMCAID%7CNONE%7CvVersion%7C3.1.2',
                    's_cc': 'true',
                    'myid5_id': 'ID5*WTi_A-ATX6JzrmhPabOZX24UqOHHYqIhmMPhFoLKIkZ5wtmN020rItq4Ieb_CtZYecNTDYRKRkbyE64f1LLVgg',
                    'utag_main': 'v_id:018cd011bd3c00673ace0afe146405075004506d00942$_sn:1$_se:3$_ss:0$_st:1704299689043$ses_id:1704297872701%3Bexp-session$_pn:1%3Bexp-session$vapi_domain:realestate.com.au$dc_visit:1$dc_event:1%3Bexp-session$_prevpage:rea%3Arent%3Asearch%20result%20-%20list%3Bexp-1704301489051$dc_region:ap-southeast-2%3Bexp-session',
                    '_sp_id.2fe7': '746a6b96-76fd-4b42-b42e-4a79e6064d00.1704297873.1.1704297889.1704297873.da9b9de4-0999-413a-97c5-ec0ede4771de',
                    'QSI_HistorySession': 'https%3A%2F%2Fwww.realestate.com.au%2Frent%2Fin-qld%2Flist-1%3FactiveSort%3Dlist-date~1704297899217',
                },
                {
                    'reauid': '9432dd17f7630100ba1b95653d000000a26e0000',
                    'Country': 'ID',
                    'split_audience': 'd',
                    'fullstory_audience_split': 'B',
                    '_sp_ses.2fe7': '*',
                    '_gcl_au': '1.1.1720245978.1704296949',
                    'topid': 'REAUID:9432DD17F7630100BA1B95653D000000A26E0000',
                    's_ecid': 'MCMID%7C46772063165198683460213288415410449763',
                    'AMCVS_341225BE55BBF7E17F000101%40AdobeOrg': '1',
                    's_cc': 'true',
                    '_lr_geo_location_state': 'JI',
                    '_lr_geo_location': 'ID',
                    'myid5_id': 'ID5*1BmjREa4Jpnvz36esMdLDhVRF4aDcufb741rESvY9Mx5wjUZokGDt4dZcfWxgr2yecMmoMlPeJqHu43ghO4rIQ',
                    'VT_LANG': 'language%3Den-US',
                    '_fbp': 'fb.2.1704296952478.1093999509',
                    'DM_SitId1464': '1',
                    'DM_SitId1464SecId12708': '1',
                    'AMCV_341225BE55BBF7E17F000101%40AdobeOrg': '-330454231%7CMCIDTS%7C19726%7CMCMID%7C46772063165198683460213288415410449763%7CMCAID%7CNONE%7CMCOPTOUT-1704304150s%7CNONE%7CMCAAMLH-1704901751%7C3%7CMCAAMB-1704901751%7Cj8Odv6LonN4r3an7LhD3WZrU1bUpAkFkkiY1ncBR96t2PTI%7CMCSYNCSOP%7C411-19733%7CvVersion%7C3.1.2',
                    '_gid': 'GA1.3.380690579.1704296955',
                    '_ga_F962Q8PWJ0': 'GS1.1.1704296976.1.1.1704297567.0.0.0',
                    'KP_UIDz-ssn': '0Rn7P2TdsQMNRXFNQpVU3dL8BaLYIlcDOUABpDOzyTW3rOoJGzaCrxnTGtJLmFyHKeJiCLupKM0OzO5nAueM3k7BRgD5bWF0LZx5CVFCaSgG0daHMpMf5SKQHfQFAqYTqU9r4fz06lHZOAwq4PrO1FaRAM1VcU21lL9JIVrYFcJUN43i',
                    'KP_UIDz': '0Rn7P2TdsQMNRXFNQpVU3dL8BaLYIlcDOUABpDOzyTW3rOoJGzaCrxnTGtJLmFyHKeJiCLupKM0OzO5nAueM3k7BRgD5bWF0LZx5CVFCaSgG0daHMpMf5SKQHfQFAqYTqU9r4fz06lHZOAwq4PrO1FaRAM1VcU21lL9JIVrYFcJUN43i',
                    'pageview_counter.srs': '5',
                    's_nr30': '1704298906793-New',
                    'nol_fpid': 'kfdyoxfzcfbblt4g43jar6rdnioir1704296955|1704296955597|1704298909471|1704298909481',
                    '_ga_3J0XCBB972': 'GS1.1.1704296953.1.1.1704298910.0.0.0',
                    '_ga': 'GA1.3.1865380336.1704296953',
                    '_gat_gtag_UA_143679184_2': '1',
                    'utag_main': 'v_id:018cd0039ab50052a3d96c6098c805075004506d00942$_sn:1$_se:13$_ss:0$_st:1704300714430$ses_id:1704296946358%3Bexp-session$_pn:5%3Bexp-session$vapi_domain:realestate.com.au$dc_visit:1$dc_event:5%3Bexp-session$dc_region:ap-southeast-2%3Bexp-session$_prevpage:rea%3Arent%3Asearch%20result%20-%20list%3Bexp-1704302514435',
                    '_sp_id.2fe7': '7987d967-c8f9-4edf-a665-24bb2702a6e7.1704296949.1.1704298914.1704296949.cd157d77-fd49-4b15-9cc5-920eb746ba14',
                    'QSI_HistorySession': 'https%3A%2F%2Fwww.realestate.com.au%2Frent%2Fin-qld%2Flist-1%3FactiveSort%3Dlist-date~1704296963975%7Chttps%3A%2F%2Fwww.realestate.com.au%2Frent%2Fin-QLD%2Flist-1%3FactiveSort%3Dlist-date~1704298921824',
                },
                {
                    'reauid': '8e32dd17f0500200198a95658201000087b80000',
                    'Country': 'ID',
                    'KP_UIDz-ssn': '0fa3zwmSp1msGDmbQug6WnfqcoMPuMjBxn7lte9TN9eLhZR5uK2in4X8R9LcxZPF9yw7q13JnRseV5MUragZBM7nLEKfXTEfQxS9aJbHsXnvx5ebAhmK5wiJCd8RDuxYB4rFOaQeWKZFsDmjI1z4JiZJwXKS9sEssWggaLLCg3hCfX5',
                    'KP_UIDz': '0fa3zwmSp1msGDmbQug6WnfqcoMPuMjBxn7lte9TN9eLhZR5uK2in4X8R9LcxZPF9yw7q13JnRseV5MUragZBM7nLEKfXTEfQxS9aJbHsXnvx5ebAhmK5wiJCd8RDuxYB4rFOaQeWKZFsDmjI1z4JiZJwXKS9sEssWggaLLCg3hCfX5',
                    'topid': 'REAUID:8E32DD17F0500200198A95658201000087B80000',
                    'split_audience': 'd',
                    'fullstory_audience_split': 'B',
                    '_sp_ses.2fe7': '*',
                    'AMCVS_341225BE55BBF7E17F000101%40AdobeOrg': '1',
                    'myid5_id': 'ID5*WTi_A-ATX6JzrmhPabOZX24UqOHHYqIhmMPhFoLKIkZ5wtmN020rItq4Ieb_CtZYecNTDYRKRkbyE64f1LLVgg',
                    's_ecid': 'MCMID%7C38166663233962946580741138631908829025',
                    'AMCV_341225BE55BBF7E17F000101%40AdobeOrg': '-330454231%7CMCIDTS%7C19727%7CMCMID%7C38166663233962946580741138631908829025%7CMCAAMLH-1704939004%7C3%7CMCAAMB-1704939004%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1704341404s%7CNONE%7CMCAID%7CNONE%7CvVersion%7C3.1.2',
                    's_cc': 'true',
                    '_gcl_au': '1.1.1682379316.1704334205',
                    'VT_LANG': 'language%3Den-US',
                    'DM_SitId1464': '1',
                    'DM_SitId1464SecId12708': '1',
                    '_lr_geo_location_state': 'JI',
                    '_lr_geo_location': 'ID',
                    '_fbp': 'fb.2.1704334207848.123377554',
                    'nol_fpid': 'bdclkfctdyf41vognsf3w8lrqx5d01704334207|1704334207856|1704334207856|1704334207856',
                    '_ga': 'GA1.3.1411920942.1704334208',
                    '_gid': 'GA1.3.143648742.1704334209',
                    '_gat_gtag_UA_143679184_2': '1',
                    'pageview_counter.srs': '2',
                    's_nr30': '1704334209558-New',
                    's_sq': '%5B%5BB%5D%5D',
                    '_ga_3J0XCBB972': 'GS1.1.1704334208.1.1.1704334209.0.0.0',
                    'QSI_HistorySession': 'https%3A%2F%2Fwww.realestate.com.au%2Frent%2Fin-qld%2Flist-1%3FactiveSort%3Dlist-date~1704334241061',
                    'utag_main': 'v_id:018cd23c1a23001e89210bc76c5105075003106d00942$_sn:1$_se:5$_ss:0$_st:1704336056505$ses_id:1704334203428%3Bexp-session$_pn:1%3Bexp-session$vapi_domain:realestate.com.au$dc_visit:1$dc_event:2%3Bexp-session$_prevpage:rea%3Arent%3Asearch%20result%20-%20list%3Bexp-1704337856511$dc_region:ap-southeast-2%3Bexp-session$adform_uid:7872685281015793544%3Bexp-session$ttd_uuid:1735fb9e-1550-483d-a1e5-8f1f5a33b455%3Bexp-session',
                    '_sp_id.2fe7': '7c0a8b2a-3dc5-4536-872f-e05fbb7510ca.1704334203.1.1704334257.1704334203.c6f05e21-6ebf-4dbb-916b-336940fa49c4',
                }
            ]
            cookie = random.choice(cookie_list)
            req = requests.get(link, params=params, cookies=cookie, headers=headers)
            soup = BeautifulSoup(req.text, "html.parser")
            
            stores = soup.select(".Card__Box-sc-g1378g-0.iyqwWq.results-card.residential-card")
            print(len(stores))
            if len(stores) != 0: break
        
        print(req.url)
        if len(stores) == 0: break
        page += 1

        for store in stores:
            price = store.select_one(".property-price ").text
            address = store.select_one(".residential-card__address-heading").text
            info = store.select(".Inline__InlineContainer-sc-lf7x8d-0.iuOPWU div div")
            try: parking = info[2]['aria-label']
            except: parking = ''
            try: bath = info[1]['aria-label']
            except: bath = ''
            bed = info[0]['aria-label']
            id_place = store.select_one(".ButtonBase-sc-18zziu4-0.iqtDgx.MoreButton__StyledButton-sc-hk6ggq-0.elVrsd")["id"].lstrip("action-menu-button-")
            type = store.select_one(".residential-card__property-type").text
            print(idx, [id_place, state.upper(), type, address, price, bed, bath, parking])
            idx += 1

            list_idplace.append(id_place)
            list_state.append(state.upper())
            list_address.append(address)
            list_price.append(price)
            list_bed.append(bed)
            list_bath.append(bath)
            list_parking.append(parking)
            list_type.append(type)
            


print('Saving Data...')
data = pd.DataFrame(list(zip(
    list_idplace,
    list_state,
    list_type,
    list_address,
    list_price, 
    list_bed, 
    list_bath,
    list_parking)), 
    
    columns=[
        'ID', 
        "State",
        "Type",
        "Address", 
        "Price",
        "Bedroom",
        "Bathroom",
        "Parking"])

file_name = link.lstrip('https://www.').split('/')[0].replace('.', '_')+'.csv'
data.to_csv(file_name, index=False)

print('Data Saved.')